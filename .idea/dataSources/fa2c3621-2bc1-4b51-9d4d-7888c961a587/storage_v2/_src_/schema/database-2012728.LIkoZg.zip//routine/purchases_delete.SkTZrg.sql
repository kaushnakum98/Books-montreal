create
    definer = `user-2012728`@localhost procedure purchases_delete(IN p_purchase_id varchar(50))
BEGIN

DELETE FROM purchases
WHERE purchase_id = p_purchase_id;

END;

