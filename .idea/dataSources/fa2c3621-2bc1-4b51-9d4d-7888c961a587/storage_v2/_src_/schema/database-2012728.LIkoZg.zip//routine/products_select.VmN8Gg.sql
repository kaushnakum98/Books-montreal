create
    definer = `user-2012728`@localhost procedure products_select()
BEGIN

SELECT * FROM products
ORDER BY product_code;

END;

