create
    definer = `user-2012728`@localhost procedure get_product_detail(IN p_productid varchar(12))
BEGIN

SELECT * FROM products 
WHERE productid = p_productcode
ORDER BY productid;

END;

