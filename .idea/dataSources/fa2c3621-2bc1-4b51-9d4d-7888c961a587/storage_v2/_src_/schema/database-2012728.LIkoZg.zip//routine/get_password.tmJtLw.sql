create
    definer = `user-2012728`@localhost procedure get_password(IN p_username varchar(50))
BEGIN

	SELECT firstname , lastname , PASSWORD , user_uuid ,username
	FROM customers
	WHERE username = p_username;

END;

