create
    definer = `user-2012728`@localhost procedure purchases_insert(IN p_product_code varchar(50),
                                                                  IN p_username varchar(50), IN p_quantity int,
                                                                  IN p_comments varchar(200),
                                                                  IN p_subtotal decimal(7, 2),
                                                                  IN p_taxes_amount decimal(7, 2),
                                                                  IN p_grand_total decimal(7, 2))
BEGIN

INSERT INTO purchases (product_id,username,quantity,comments,subtotal,taxes_amount,grand_total)
VALUES (p_product_code,p_username,p_quantity,p_comments,p_subtotal,p_taxes_amount,p_grand_total);

END;

