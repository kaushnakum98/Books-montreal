create
    definer = `user-2012728`@localhost procedure customer_insert(IN p_username char(50), IN p_password varchar(255),
                                                                 IN p_firstname char(50), IN p_lastname char(50),
                                                                 IN p_address char(50), IN p_city char(50),
                                                                 IN p_provience char(50), IN p_postalcode varchar(50))
BEGIN

INSERT INTO customers(username,password,firstname,lastname,address,city,provience,postalcode)
VALUES (p_username , p_password , p_firstname,p_lastname,p_address,p_city,p_provience,p_postalcode);

END;

