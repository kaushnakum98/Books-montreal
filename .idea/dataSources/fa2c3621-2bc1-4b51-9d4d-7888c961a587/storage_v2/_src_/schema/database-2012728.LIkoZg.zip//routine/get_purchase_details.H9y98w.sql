create
    definer = `user-2012728`@localhost procedure get_purchase_details(IN p_purchaseid varchar(50))
BEGIN

SELECT * FROM purchases 
WHERE purchase_id = p_purchaseid;

END;

