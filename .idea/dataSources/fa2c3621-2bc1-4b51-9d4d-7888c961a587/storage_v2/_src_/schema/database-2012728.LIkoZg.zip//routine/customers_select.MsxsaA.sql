create
    definer = `user-2012728`@localhost procedure customers_select(IN p_username varchar(12))
BEGIN

	SELECT * 
	FROM customers 
	WHERE username = p_username
	ORDER BY firstname;
	

END;

