create
    definer = `user-2012728`@localhost procedure customers_select(IN p_userid varchar(50))
BEGIN

	SELECT * 
	FROM customers 
	WHERE user_uuid = p_userid
	ORDER BY firstname;
	

END;

