create
    definer = `user-2012728`@localhost procedure customers_all()
BEGIN

SELECT * FROM customers
ORDER BY username;

END;

