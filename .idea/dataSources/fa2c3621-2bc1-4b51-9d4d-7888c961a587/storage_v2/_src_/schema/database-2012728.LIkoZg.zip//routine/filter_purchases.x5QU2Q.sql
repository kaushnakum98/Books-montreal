create
    definer = `user-2012728`@localhost procedure filter_purchases(IN p_date timestamp, IN p_userid varchar(50))
BEGIN

IF p_date IS NOT NULL THEN
    SELECT pu.purchase_id, pr.product_code, cu.firstname , cu.lastname  , cu.city , pu.comments, pr.price ,pu.quantity ,pu.subtotal , pu.taxes_amount ,pu.grand_total
    FROM customers cu , products pr , purchases pu
    WHERE cu.user_uuid = pu.username
      AND pu.product_id = pr.productid
      AND date(p_date) <= pu.created_at
      AND pu.username = p_userid
    ORDER BY pu.created_at;
ELSE
    SELECT  pu.purchase_id, pr.product_code, pr.product_code,cu.firstname , cu.lastname  , cu.city , pu.comments,pr.price ,pu.quantity ,pu.subtotal , pu.taxes_amount ,pu.grand_total
    FROM customers cu , products pr , purchases pu
    WHERE cu.user_uuid = pu.username
    AND pu.product_id = pr.productid
    AND pu.username = p_userid
    ORDER BY pu.created_at;

END IF;
END;

