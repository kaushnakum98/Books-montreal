create
    definer = `user-2012728`@localhost procedure purchases_update(IN p_procuct_id varchar(50),
                                                                  IN p_product_code varchar(12), IN p_username char(12),
                                                                  IN p_quantity int, IN p_comments varchar(200),
                                                                  IN p_subtotal decimal(7, 2),
                                                                  IN p_taxes_amount decimal(7, 2),
                                                                  IN p_grand_total decimal(7, 2))
BEGIN

UPDATE purchases 
SET product_code = p_product_code,username = p_username ,quantity = p_quantity,comments =p_comments,subtotal = p_subtotal , taxes_amount = p_taxes_amount , grand_total = p_grand_total ,updated_at = NOW()
WHERE purchase_id = p_procuct_id;

END;

