create
    definer = `user-2012728`@localhost procedure filter_purchases(IN p_date date, IN p_userid varchar(50))
BEGIN

IF p_date IS NOT NULL THEN
    SELECT * FROM purchases
    WHERE TRY_CONVERT(p_date, timestamp) = created_at
    AND username = p_userid
    ORDER BY created_at;
ELSE
    SELECT * FROM purchases
    WHERE username = p_userid
    ORDER BY created_at;

END IF;
END;

