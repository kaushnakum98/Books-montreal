create
    definer = `user-2012728`@localhost procedure products_delete(IN p_productid varchar(12))
BEGIN

DELETE FROM products
WHERE product_code = p_productid;

END;

