create definer = `user-2012728`@localhost view `view-2012728` as
select `database-2012728`.`products`.`productid`   AS `productid`,
       `database-2012728`.`products`.`description` AS `description`,
       `database-2012728`.`products`.`price`       AS `price`,
       `database-2012728`.`products`.`cost_price`  AS `cost_price`,
       `database-2012728`.`products`.`created_at`  AS `created_at`,
       `database-2012728`.`products`.`updated_at`  AS `updated_at`
from `database-2012728`.`products`
order by `database-2012728`.`products`.`productid`;

