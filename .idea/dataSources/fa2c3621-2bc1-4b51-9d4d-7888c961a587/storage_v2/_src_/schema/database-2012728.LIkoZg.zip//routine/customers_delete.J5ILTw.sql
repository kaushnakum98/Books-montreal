create
    definer = `user-2012728`@localhost procedure customers_delete(IN p_userid varchar(50))
BEGIN

	DELETE  
	FROM customers 
	WHERE user_uuid = p_userid;

END;

