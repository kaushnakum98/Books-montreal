create
    definer = `user-2012728`@localhost procedure purchases_select(IN p_username varchar(12))
BEGIN

SELECT * FROM purchases
WHERE username = p_username
ORDER BY purchase_id;

END;

