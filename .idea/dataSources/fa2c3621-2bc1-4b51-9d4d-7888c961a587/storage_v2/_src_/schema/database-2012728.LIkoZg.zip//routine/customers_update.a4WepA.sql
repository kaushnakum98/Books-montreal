create
    definer = `user-2012728`@localhost procedure customers_update(IN p_username varchar(50), IN p_password varchar(255),
                                                                  IN p_firstname char(50), IN p_lastname char(50),
                                                                  IN p_address varchar(50), IN p_city char(50),
                                                                  IN p_provience char(50), IN p_postalcode varchar(50))
BEGIN

UPDATE customers
SET firstname = p_firstname , lastname = p_lastname, address = p_address, city = p_city,provience = p_provience,postalcode = p_postalcode , PASSWORD = p_password ,updated_at = NOW()
WHERE username = p_username;

END;

