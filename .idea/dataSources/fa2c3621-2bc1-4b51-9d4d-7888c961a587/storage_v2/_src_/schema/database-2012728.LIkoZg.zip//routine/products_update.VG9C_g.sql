create
    definer = `user-2012728`@localhost procedure products_update(IN p_productid varchar(12),
                                                                 IN p_description varchar(100),
                                                                 IN p_price decimal(4, 2),
                                                                 IN p_cost_price decimal(10, 2))
BEGIN

UPDATE products 
SET description = p_description ,price = p_price ,cost_price = p_cost_price , updated_at = NOW()
WHERE product_code = p_productid ;

END;

